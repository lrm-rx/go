import { Entity } from "typeorm"

@Entity()
export class entity {

}
