import { Controller } from '@nestjs/common';

@Controller('logs')
export class LogsController {}
